# Supplied-template visual audit — 5 November 2026

Current authority: the user's `LaTeX-Templates` folder and its supplied `acmart` 1.90a class. All 55 reference files and the four active class/source/BST files match the supplied ZIP. Entry files start with the sample's documentclass command. The earlier production-2.21 inspection below is historical and does not identify the current PDFs.

All 34 pages were rendered at 144 dpi and checked across five contact sheets, with reading-size inspection of named/anonymous first pages, the full-width comparison table, historical results table, tiny contract example, Figure 1 and final references. The current identities are in `visual-inputs.json`; rendered pages and properties are retained in the parent workspace under `preparation/2026-11-05-template-folder/`.

- Named review: 10 pages; compact: 5; anonymous review: 10; anonymous compact: 5; supplement: 4.
- All pages use Letter geometry and embedded native fonts; PDF creators identify supplied acmart 1.90a.
- Four authors, their affiliations and Hieu's correspondence note are intact; named compact displays all four emails. Native manuscript rendering follows the supplied class. Anonymous profiles omit author identity markers.
- Both tables use native text size. Table 1 spans the compact page width, keeping all four comparison columns readable; Table 2 wraps within its column. Captions and Figure 1 labels are clear.
- Standard paragraph headings and seven scoped `sloppypar` environments follow the local guide. The latter resolve body line-breaking warnings without font or margin changes.
- No body overflow, observed clipping, overlap or missing glyphs. The native output routine retains one named-compact 4.18721 pt horizontal-box diagnostic and one anonymous-compact 1.152 pt vertical-box diagnostic. Both final pages are complete and legible. Validation permits only these exact profile/context/size/count combinations and reports them explicitly; any other overflow fails.

This records technical visual inspection; submission and author declarations retain their separate status.

---

# Final guide-current visual review — 5 November 2026

All five profiles use the unmodified ACM production 2.21 class and bibliography
style. The main review profiles have 10 pages each, compact previews 5 each,
and the technical supplement 4: 34 rendered pages in total. All page geometries
are standard Letter (612 by 792 PDF points); every inspected font is embedded.

Full-document contacts and the changed first pages, paragraph headings, Figure 1,
both tables, tiny example and complete references were inspected. The four-author
order, Hieu correspondence note, native ACM Reference Format and Authors' Contact
Information block render correctly. Standard paragraph headings are clear; table
and figure descriptions are present in source. The documented pbalance option
balances the compact reference columns. No clipping, overlap or missing symbols
was observed. The supplement now uses the same four actual author records and
complete abstract, CCS, keywords and native reference metadata.

The named review has Table 1 and the tiny example on page 3, Figure 1 on page 4
and the real-project discussion on page 6. The compact preview places the table
and example on page 2, Figure 1 on page 3 and the real-project discussion on
page 4. Both anonymous profiles retain all four items and pass identity checks.

One 1.1135 pt anonymous-compact vertical output-box diagnostic remains on the
balanced bibliography page. It is retained explicitly in validation.json and
has no observed visible defect. The stricter validator rejects horizontal,
larger vertical or other-profile overflow. No unresolved citations or references
or ignored postal/mandatory-metadata warnings remain.

The scientific wording matches merged revision 586150f after normalizing only
heading markup and visual descriptions. The dated guide snapshots, normalization
check and final renders are retained in the parent workspace at
preparation/2026-11-05-final-guide-audit/. visual-inputs.json binds the current
PDFs. Earlier records below retain their original versions and author scopes.

# Integrated PR #60 / PR #61 visual review — 4 November 2026

## Current four-author review revision

All five venue profiles were rebuilt with TeX Live and rendered at 144 dpi.
The four authors appear in the agreed order, with Vo Duc Hieu carrying the
corresponding-author note. Per-author affiliations, four emails and four ORCIDs
remain synchronized with metadata. The ACM citation presentation and native
compact balancing from PR #60 are retained alongside all five review fixes.

The named compact profile has Table 1 and the tiny example on page 2, Figure 1
on page 3 and the real-project discussion on page 4. In the named review
profile these are on pages 2, 3, 4 and 6 respectively. All four main profiles
contain the figure, comparison column, example and discussion. The five page
counts remain 10/5/10/5/3. Full-document contacts and changed-page renders were
inspected without observed clipping or overlap.

The compact named log retains the 4.18721 pt bibliography output-box warning
already documented in PR #60. The anonymous compact log reports a 1.152 pt
vertical output-box warning on the final bibliography page; the rendered page
shows complete, readable references without visible clipping. These diagnostics
are retained, and the existing validation exception has not been broadened.
No unresolved citations or references were found.

`visual-inputs.json` binds this rebuild. Page renders and content-presence checks
are retained in the parent workspace at
`preparation/2026-11-04-pr60-pr61-integration/`. Earlier dated reviews below
retain their original author and rendering scopes.

# Visual review — 4 November 2026

## Earlier six-author five-comment manuscript revision

All five profiles were rebuilt with Tectonic and rendered at 144 dpi. Full-document
contact sheets were inspected; the changed comparison table, tiny example and
workflow were inspected at page size, with an additional 216 dpi Table 1 caption
detail. Table 1 uses a dedicated Language / focus column and ragged-right cells
at the existing font size. Figure 1 is embedded as vector/text content and its
stage labels, arrows and decision caption are legible. No clipping, overlap or
column overflow was observed. Two conditional-boundary word-spacing defects
were corrected and verified in the final PDF text.

The named compact profile has Table 1 and the tiny example on page 2, Figure 1
on page 3, and the real-project discussion on page 4. The named review profile
has Table 1 and the example on page 3, Figure 1 on page 4, and the real-project
discussion on page 6. Both anonymous main profiles also contain all four items.
The compact profiles remain 5 pages, review profiles 10, and supplement 3.

The strict builder reports no overfull boxes or unresolved citations/references.
Author identities, anonymous redaction, the 17-citation set, abstract metadata
and retained evidence hashes pass validation. `visual-inputs.json` binds the
final PDFs. Renders and content-presence checks are retained in the parent
workspace at `preparation/2026-11-04-paper-review/`.

Earlier dated reviews below are retained as history.

# Earlier visual review - 29 September 2026

## Earlier four-author candidate before review-comment integration

The owner removed Hoang Nguyen-The and Minh Tam Phan and moved the
corresponding-author star to Vo Duc Hieu. The named compact and review first
pages were rendered at 1800 pixels and inspected: only Hieu, Hoang, Kiet and
Bach appear, in that order. The compact email line and all affiliations remain
legible. The compact last page was also inspected; references are readable
without clipping or overlap. The four main profiles remain 10/5/10/5 pages.
The official class is unchanged. The compact TeX output routine reports one
4.18721 pt overfull box on the last bibliography page; no visible overflow was
found, and the validator allows only this one sub-5-pt compact warning. This
presentation review is not coauthor consent or submission authorization.

## Owner-requested publisher-phrase omission

The named compact first page was rebuilt and inspected after removing the
generated `ACM, New York, NY, USA` publisher phrase from the ACM Reference
Format block. The separate ICIIT
conference line continues to show Ho Chi Minh City, Vietnam. The first-page
author block, abstract, columns and footnote remain legible without observed
clipping or overlap. The official class file remains unchanged. This is a
presentation exception to the supplied ACM sample, not proof of venue approval.
The five rebuilt PDF hashes are recorded in `visual-inputs.json`.

## Earlier compact submission candidate (superseded author list)

The named five-page `sigconf` candidate was rebuilt from the official class
without the earlier `balance=false` override. All five pages were rendered
and inspected on 29 September. The first page visibly retains the six-author
order and unchanged email sequence. It displays Vo Duc Hieu in Software
Engineering at FPT University, Tran Minh Hoang in Computer Science and
Engineering at VNUK, Le Van Kiet in Software Engineering at VNUK, and Ha
Hoang Bach in Information Assurance at FPT University, with their respective
Ho Chi Minh City or Da Nang locations. The last reference page now balances
its columns. No clipping, overlap, or lost content was observed on the five
rendered pages. The single-column review first page was also inspected;
ACM's manuscript renderer prints institution/country there but retains the
full affiliation in source and metadata. The official event name replaces
the visible `Draft for` prefix without inventing DOI, ISBN or rights data.
`visual-inputs.json` binds the five rebuilt PDF files. This is a layout check,
not D3 validation, coauthor consent or submission authorization.

## Earlier standard ACM author renderer restoration (superseded author list)

The named review and compact first pages were rebuilt with the unmodified
`acmart` author renderer and inspected at 150 dpi. The six supplied authors
remain in the requested order with their structured affiliations, emails and
four supplied ORCIDs; Minh Tam Phan carries the native corresponding-author
note. The review profile uses ACM's manuscript presentation, while the compact
profile uses ACM's conference grid. Neither page shows observed clipping,
overlap or column spill. Page counts remain 10/5/10/5/3. The custom author
layout described in older entries below is historical and superseded by this
build.

## Reviewer-role attribution correction (current)

The five ACM profiles were rebuilt with the pinned TeX Live 2024 image after
replacing an unsupported claim that both D3 reviewers developed the tool with
the supported statement that both are development-associated authors with
prior output exposure. Review page 6 and compact page 4 were rendered at
180 dpi and inspected. The corrected limitation and surrounding conclusion
remain legible without clipping, overlap, or column spill. Page counts remain
10/5/10/5/3. This check concerns presentation and attribution accuracy; it
does not establish independent D3 labels, results, or submission approval.

## D3 scope and nonblind-review clarification (current)

The five ACM profiles were rebuilt in the pinned TeX Live 2024 hosted job
36370633982 after updating the venue-specific paper and appendix. Fresh PDF
validation passed; page counts remain 10/5/10/5/3. I rendered and inspected
the affected review pages 8-10, compact pages 4-5, and supplement page 3.
The D3 boundary, limitations and references are legible without observed
clipping or overlap. The compact conclusion and references retain their
existing two-column layout. This visual inspection checks presentation only;
it does not authenticate reviewer labels, a tool comparison, or submission
readiness. The current PDF hashes are in visual-inputs.json.

## Concurrent refinement integration (current)

All five profiles were rebuilt and their complete 1600px page render contact
sheets inspected in tmp/pdfs/concurrent-integration/. Resolved section/figure
references, the explicit result-to-RQ mapping, disclosure heading and corrected
proceedings citation render without observed clipping or overlap. Page counts
remain 10/5/10/5/3; all 26 local validator regression tests pass. Current hashes
are in visual-inputs.json. Prior observations below belong to prior builds.
These presentation checks do not add independent experimental evidence.

## Earlier bibliographic field correction

All five profiles were rebuilt, rendered at 1600px and inspected as complete
contact sheets in tmp/pdfs/bibliography-revision/. The compact reference page
was also inspected at full size. Qayum now visibly cites the 2025 issue,
55(1), 100-132 while retaining the online-2024 note; Schneider visibly uses
Article 128 rather than page 128. Added publisher locations do not cause
observed clipping or overlap. Page counts remain 10/5/10/5/3. Twenty-six local
regression checks pass. visual-inputs.json binds these PDFs; earlier hashes
below are historical. No D1/D2/P3 result, author order, scientific claim or
independent-evaluation status changed.

## Earlier scientific reviewer revision

All five regenerated profiles were rendered and their full-document contact
sheets inspected in tmp/pdfs/reviewer-revision/. The motivation-first abstract,
focused 17-reference narrative, pinned repo links, explicit development-result
caption and benchmark interpretation are readable without observed clipping or
overlap. Review/compact remain 10/5 pages; supplement is 3 pages. The author
typography is unchanged. Anonymous text and annotation checks omit identifying
repo URLs. Earlier visual receipts below are historical, not current hashes.
visual-inputs.json binds this revision. Scientific gaps remain in the reviewer
response; layout validation does not close them.

## Current screenshot-style typography correction

The owner's repeated request to match the sample exposed a rendering issue:
acmart's roman URL font overrode the prior outer typewriter declaration.
The corrected block explicitly uses T1 Times-style 12pt/14pt text for names
and affiliation, a 12pt gap between those groups, and T1 bold Courier-style
10pt/12pt text for the three email lines. A local UrlFont definition prevents
the class from changing the email face. No body font or margin is changed.

Both first pages were re-rendered at 1800px and visually inspected against the
sample. All named pages were re-rendered into contact sheets with no observed
clipping or overlap. PDF text visitors confirm actual NimbusRomNo9L-Regu and
NimbusMonL-Bold fonts (not a LaTeX-only assertion). Fifteen regression tests
pass, including a test rejecting serif email fallback.
The previous six-author metadata, order and correspondence star are unchanged.
Review/compact remain 10/5 pages; the anonymous and supplement page text is
unchanged. visual-inputs.json binds these inspected PDFs. Current first-page
renders are in tmp/pdfs/exact-author-style/; full contact sheets are in
tmp/pdfs/shared-author-block/. Organizer acceptance of the customization is
still not asserted.

## Earlier shared-affiliation layout (typography superseded)

The latest explicit owner request replaces the default author renderer for
the two named ICIIT profiles only. Both first pages were rendered at 1700px and
inspected; all 15 named-profile pages were also rendered into contact sheets.
No observed clipping, overlaps or lost content. Review/compact remain 10/5
pages. The centered two-line name list, shared faculty/address, bold email
lines, Kiet-before-Bach order, Hoang Nguyen-The spelling and Minh Tam Phan star
match the user's typed block and example presentation.

Four ORCIDs remain associated with their original authors in structured
metadata; they are not added to the visible block. The research source from
the abstract onward is byte-identical to the previous candidate. Anonymous
and supplement extracted page text is identical to the previous version.
All five profiles pass semantic, citation, evidence-hash, no-overflow and
identity checks; 13 targeted regression tests pass.

Renders are in tmp/pdfs/shared-author-block/. visual-inputs.json binds the
inspected PDFs. This intentional custom layout needs organizer confirmation;
visual inspection supplies neither coauthor consent nor submission approval.

## Earlier official-template author layout (superseded)

The owner selected the unmodified ACM author renderer. Both named first pages
were inspected at full size; all five venue profiles were rendered and checked
as page contact sheets after restoring ACM Reference Format. No observed
clipping or overlap. Review/compact remain 10/5 pages and supplement 3.
The review renderer's uppercase names and omitted emails are class behavior;
six source email records remain exact, and compact mode displays them.
Four ORCIDs remain in source. No optional contribution section is present.

Rendered checks are retained locally at tmp/iciit-audit-20260927/. The changed
IEEE endings were also inspected after removing their role lists; contribution
records are outside the typeset paper. The latest visual-inputs.json binds the
current venue PDFs. This is technical layout inspection, not author consent,
independent scientific validation or submission approval.

## Earlier PR #50 author-order correction (superseded layout)

The earlier Windows/Tectonic rebuild restored the owner-confirmed order while
keeping two affiliation groups. The changed named first pages were rendered
and inspected, together with reference/appendix and supplement layout checks.
No observed clipping or overlap was introduced. Extracted text, metadata,
25 citations, evidence hashes, and 5/10/5/10/3-page budgets pass the validator.
Anonymous profiles pass identity redaction. The updated visual-inputs.json
binds these rebuilds; renders are in the parent workspace at
tmp/pr50-fix-20260927/visual/. This is technical presentation review, not
independent research or submission approval.

## Earlier full-document review (retained history)

All five profiles were rendered with PDFium and inspected as full-document contact sheets. The named compact first page was also inspected at full size. The two-university author grouping, correspondence footnote, abstract, Table 1, workflow figure, evaluation table, Section 6 and references render without observed clipping or overlap. Line-numbered review versions remain readable. Current compact profiles have 5 pages each; review profiles 10 pages each; supplement 3 pages.

Names, emails, affiliations and supplied ORCIDs are checked for absence in anonymous extracted text and PDF metadata. Named PDFs retain all six names/emails; ORCIDs are retained in structured source rather than displayed. The class-generated anonymous thanks placeholder contains no identity. These PDF checks cannot erase prior public repository history.

`visual-inputs.json` binds the inspected artifacts. Render files are retained at `preparation/2026-09-27-iciit-rework/visual/` in the parent workspace. The strict validator reports no overfull boxes, unresolved citations or unresolved references. All 25 citations and the existing Table 1 are retained. These checks concern presentation and consistency, not author consent or independent scientific review.

Standalone-source compatibility follow-up: all five retained profiles have
identical page text and rendered pixels at 72 dpi to reviewed head 1fa2967.
Author presentation, scientific claims and evidence remain unchanged.

## Per-author affiliation correction — 29 September 2026

The named compact and review first pages were rendered and inspected after the
owner corrected the author affiliations. The compact profile visibly places
Tran Minh Hoang and Le Van Kiet at VNUK Institute for Research and Executive
Education, The University of Danang, with Computer Science and Engineering and
Software Engineering respectively. Vo Duc Hieu appears in Software Engineering
at FPT University, and Ha Hoang Bach appears in Information Assurance at FPT
University. The two faculty-author records retain FPT University HCMC. The
standard ACM layout remains readable without clipping, overlap or a page-count
change. Automated checks bind all five current PDFs in `visual-inputs.json` and
confirm that anonymous profiles contain none of the author identity fields.

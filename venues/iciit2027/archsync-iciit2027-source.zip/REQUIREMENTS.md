# ICIIT 2027 (Ho Chi Minh City) — verified draft requirements

Verified 2026-09-26 from the official pages captured under `official/` with URL,
UTC retrieval time and SHA-256 in `official/retrieval.json`.

| Item | Official evidence and consequence |
| --- | --- |
| Identity/location | 12th International Conference on Intelligent Information Technology, March 4–7, 2027, Ho Chi Minh City, Vietnam. [Home](https://www.iciit.org/) and [venue](https://www.iciit.org/venue.html). |
| Destination | ACM conference proceedings is the draft target, distinct from the site's alternative journals. This is an advertised destination, not an acceptance or independent indexing guarantee. [Submission](https://www.iciit.org/sub.html). |
| Dates | Full paper September 30, 2026; abstract October 5; notification October 20; registration November 10. No submission time zone or cutoff time is stated. [Dates](https://www.iciit.org/date.html). |
| Format | English; official submission page links [LaTeX archive](https://www.iciit.org/LaTeX-Templates.zip). The supplied `sample-sigconf.tex` instructs review manuscripts to use `manuscript,screen,review`, and final manuscripts to use `sigconf` or the required publication style. The draft uses the actual archive's unmodified class and bibliography style. |
| Length | Submission page describes minimum 8 single-column or 4 double-column pages, including references. Regular registration covers 10 single-column or 5 double-column pages; additional pages incur charges. A hard maximum is not stated. This is not an IEEE 10+2 rule. |
| Review identity | Neither the checked submission page nor supplied sample specifies venue-specific blind review. Both named and technically anonymized profiles are supplied; this does not establish the correct upload profile or erase public history. |
| Fit | The [call for papers](https://www.iciit.org/cfp.html) includes intelligent software systems, service-oriented computing, and information extraction/classification. The draft emphasizes auditable extraction and deterministic conformance decisions; it does not invent AI efficacy. |
| Publication obligations | At least one accepted-paper author must register; proceedings publication is conditional on acceptance, registration and presentation. [Registration](https://www.iciit.org/reg.html). |
| Cost | Additional pages are advertised at USD30 each. Author registration and possible APC are distinct; eligibility and the site's conference-discount arrangement need confirmation before any payment. No purchase is authorized by this draft. |

Fresh raw `date.html` matches the homepage's October 20/November 10 dates. A
separate cached retrieval yielded October 30/November 30; the dated raw capture
is the evidence used here. Recheck dates immediately before submission. The
linked CFP brochure returned 404 during this check; the live HTML CFP supplies
the scope evidence instead.

## What the draft contains

- A compact venue-specific treatment, retaining 25 citations and the original
  bounded D1/D2/P3 results. It does not replace the longer IEEE working drafts.
- A separate technical-reliability section covering the finite Core oracle,
  mutation-driven test improvement and current Guardian repairs; no results
  are promoted to independent field accuracy.
- A factual methods-provenance paragraph describing AI assistance in research
  code/testing and the lack of independent human validation of this extension.
  This follows the [ACM authorship policy, updated May 14, 2026](https://prod-www.acm.bloomreach.cloud/publications/policies/new-acm-policy-on-authorship),
  which requires methods disclosure for research uses. Writing assistance alone
  is treated differently by that policy. This is methodological provenance,
  not an assistant signature or a fabricated author approval.
- Six authors and existing affiliation/email/ORCID information transferred from
  the current manuscript. No new author consent, funding, conflict, ORCID or
  submission-exclusivity declaration was invented.

## Unresolved before upload

Confirm the venue's review profile (single/double column and named/anonymous),
submission cutoff time zone, and any supplementary-file acceptance. Authors must
review the actual candidate, its new evidence/provenance, authorship/order,
conflicts/funding and simultaneous-submission status. Two existing authors have
no ORCID in the repository; do not fabricate them. ACM publication rights fields
must come from the real rights process after acceptance, not template examples.

The class is unchanged. Sample DOI/ISBN/copyright claims are removed and the
conference metadata explicitly identifies a draft. The absence of such fields
is intentional until genuine rights metadata exists. No submission, registration,
email, payment, public release or acceptance has occurred in this preparation.

## Historical user-specified presentation (superseded)

On 26 September 2026 the user supplied a centered symbolic affiliation layout and requested it explicitly. `author-layout.tex` implements that presentation for named profiles while preserving ACM author metadata. This intentional author-layout customization supersedes the earlier default author grid; it is not a venue requirement or organizer approval. The user explicitly prohibits using identity information from the image. All author data is preserved from the pre-existing manuscript.

## 27 September recheck

The fresh official class and bibliography still match this package; see `official/2026-09-27/retrieval.json`. Current draft profile selection and unresolved anonymity policy are recorded in `DRAFT-CHECKLIST.md`. University-only author grouping supersedes earlier department-level presentation at user request.

## Earlier same-day instruction: default ACM author presentation (superseded)

The owner's later 27 September response explicitly selects the default ACM
author layout while preserving the confirmed six-author order. The custom
renderer is removed. The standard ACM Reference Format block is restored;
DOI/ISBN remain empty until the real rights process. No optional role list is
typeset. Research-use AI disclosure remains in methods. This supersedes all
historical custom layout instructions above; see SUBMISSION-AUDIT-20260927.md
for the current official-source check and unresolved requirements.

## Latest instruction: shared FPT author block

The owner subsequently supplied the exact centered block to use. The ICIIT
named profiles now display Vo Duc Hieu, Tran Minh Hoang, Le Van Kiet,
Ha Hoang Bach, Hoang Nguyen-The, and Minh Tam Phan with a star on the last name.
The owner supplied one common faculty/address and the six email addresses in
that order. Structured metadata is aligned; existing ORCID ownership is retained.
This supersedes the earlier default-renderer selection, not the official venue
rules. The custom layout needs organizer confirmation. Research content,
measurements, anonymous rendering and historical IEEE working files are unchanged.
